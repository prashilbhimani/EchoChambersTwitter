import React, { Component } from 'react';

class SearchBar extends Component { // has to extend this

  constructor (props) {
    super(props);

    this.state = {term : ''} // this is the ONLY place that this should happen. Anywhere else use setState
  }

  render() { // each class component has to have a render method
    return (
      <div className="search-bar">
        <input
          value = {this.state.term}
          onChange={ event => this.onInputChange(event.target.value)} />
        value of input: {this.state.term}
      </div>
    );

    /*
    return <input onChange={ event => console.log(event.target.value)} />
          onInputChange(event) {
            console.log(event.target.value)
          }
        Right now we have <input onChange={ event => console.log(event.target.value } />
        This can be re-written as  <input onChange={ (event) => console.log(event.target.value } />
        Which can be re-written as  <input onChange={ event => console.log(event.target.value) } /> // no () for event cause its a single param func
        Lets use the one above and remove the  onInputChange function cause we dont need it anymore
     */
  }

  onInputChange(term) {
    this.setState({ term: term})
    this.props.onSearchTermChange(term)
  }
}


export default SearchBar;