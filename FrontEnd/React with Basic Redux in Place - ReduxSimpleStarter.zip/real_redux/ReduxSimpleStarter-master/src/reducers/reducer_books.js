export default function() {
  return [
    { title: 'Javascript', pages: 101},
    { title: 'harry Potter', pages: 39 },
    { title: 'Dark Tower', pages: 85 },
    { title: 'Ruby', pages: 1 }
  ]
}