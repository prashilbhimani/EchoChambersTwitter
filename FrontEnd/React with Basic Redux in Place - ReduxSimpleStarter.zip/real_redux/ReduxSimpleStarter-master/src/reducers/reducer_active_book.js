export default function(state = null, action) {
  // state should always be defined so default it to null. Not good practice, make sure it has a good default value
  // all reducers have 2 parameters.
  // state is not application state. It is only the state that this reducer is reponsible for
  switch (action.type){
    case 'BOOK_SELECTED':
      return action.payload;
  }
  return state;
}