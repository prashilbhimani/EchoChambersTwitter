export function selectBook(book) {
  // this is an action creator that needs to return an action
  /*
    action has 2 types: type and payload.
    type: Just described what the action does
   */
  return {
      type: 'BOOK_SELECTED',
      payload: book
  };
}